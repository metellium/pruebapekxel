<!DOCTYPE HTML>
<html>
	<head>
		<title>Prueva de vacante en Pekxel</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="css/formulario.css" />		

</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Porfavor rellena este sencillo Formulario')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('formulario.store')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="tipo_ciclismo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Qué tipo de ciclismo practicas?')); ?></label>

                            <div class="col-md-6">
                                <select id="tipo_ciclismo" class="form-control<?php echo e($errors->has('tipo_ciclismo') ? ' is-invalid' : ''); ?>"  name="tipo_ciclismo" value="<?php echo e(old('tipo_ciclismo')); ?>" required autofocus>
                                <option value="Montaña">Montaña</option>
                                <option value="Ciudad">Ciudad</option>
                                <option value="Otro">otro</option>
                                </select>
                                <?php if($errors->has('tipo_ciclismo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipo_ciclismo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="anios" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Años usando Bicicleta')); ?></label>

                            <div class="col-md-6">
                                <input id="anios" type="number" class="form-control<?php echo e($errors->has('anios') ? ' is-invalid' : ''); ?>"  name="anios" value="<?php echo e(old('anios')); ?>" required>

                                <?php if($errors->has('anios')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('anios')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="horas" class="col-md-4 col-form-label text-md-right"><?php echo e(__('¿Cuantas horas a la semana usas tu bicilcleta?')); ?></label>

                            <div class="col-md-6">
                                <input id="horas" type="number" class="form-control<?php echo e($errors->has('horas') ? ' is-invalid' : ''); ?>" name="horas" value="<?php echo e(old('horas')); ?>" required autofocus>

                                <?php if($errors->has('horas')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('horas')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>                        
                                         
                    
                        <div class="form-group row">
                            <label for="marcas" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Escribe las marcas que más te agraden')); ?></label>

                            <div class="col-md-6">
                                <input id="marcas" type="text" class="form-control<?php echo e($errors->has('marcas') ? ' is-invalid' : ''); ?>" placeholder="Ejemplo: benotto" name="marcas" value="<?php echo e(old('marcas')); ?>" required autofocus>

                                <?php if($errors->has('marcas')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('marcas')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary" id="enviar"  onclick="ejecutarAjax()">
                                    <?php echo e(__('Enviar')); ?>

                                </button>
                                <div id="load"></div>
                                <script type="text/javascript">
                                function ejecutarAjax() {

                                    var resultado = document.getElementById("load");
                                    var ajaxRequest = new XMLHttpRequest();                                    
                                    
                                    $('#enviar').attr("disabled", true);
                                    resultado.innerHTML += "<br>" +"Muchas gracias!";
                                }
                                </script>
                                <a href="<?php echo e(route('formulario.index')); ?>"class="btn btn-success">Omitir Formulario</a>
                            </div>
                        </div>                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>