<?php $__env->startSection('content'); ?>

<table class="table table-striped">
        <thead>            
            <th>id De Formulario</th>
            <th>Tipo de ciclismo</th>
            <th>Años usando Bicicleta</th>
            <th>Horas a la semana</th>
            <th>Marcas favoritas</th> 
            <th>Acción</th>        
        </thead>
        <tbody>         
        <?php $__currentLoopData = $formulario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resumen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                <tr>               
                    <td><?php echo e($resumen->id); ?></td>
                    <td><?php echo e($resumen->tipo_ciclismo); ?></td>
                    <td><?php echo e($resumen->anios); ?> Años</td>
                    <td><?php echo e($resumen->horas); ?> Horas</td>                                        
                    <td><?php echo e($resumen->marcas); ?></td> 
                    <td><a href="<?php echo e(route('formulario.edit',$resumen->id)); ?>"class="btn btn-warning">Editar</a></td>                                        
                    <td><a href="<?php echo e(route('admin.formulario.destroy',$resumen->id)); ?>" onclick="return confirm('Seguro que deseas elimiarlo?')"class="btn btn-danger">Eliminar</a></td>                   
                </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
        </tbody>
    </table>
    <a href="<?php echo e(route('formulario.index')); ?>"class="btn btn-success">Regresar</a>
    <a href="/"class="btn btn-success">Llenar nuevo formulario</a>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>